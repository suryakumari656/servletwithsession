package com.capgemini.servlet.services;

import java.util.List;

import com.capgemini.servlet.dto.EmployeeBean;

public interface EmployeeServices {
	public EmployeeBean authenticate(int empId, String password);

	public EmployeeBean getEmployeeDetailById(int id);

	public boolean deleteEmployeeInfo(int id);

	public boolean updateEmployeeInfo(String name);

	public boolean createEmployeeInfo(EmployeeBean bean);

	public List<EmployeeBean> getAllEmployeeDetail();

}
