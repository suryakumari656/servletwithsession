package com.capgemini.servlet.dao;

import java.util.List;

import com.capgemini.servlet.dto.EmployeeBean;

public interface EmployeeDAO {

	public EmployeeBean authenticate(int empId, String password);

	public EmployeeBean getEmployeeDetailById(int id);

	public boolean deleteEmployeeInfo(int id);

	public boolean updateEmployeeInfo(String name);

	public boolean createEmployeeInfo(EmployeeBean bean);

	public List<EmployeeBean> getAllEmployeeDetail();

}
