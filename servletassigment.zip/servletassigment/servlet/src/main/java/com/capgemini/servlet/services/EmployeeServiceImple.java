package com.capgemini.servlet.services;

import java.util.List;

import com.capgemini.servlet.dao.EmployeeDAO;
import com.capgemini.servlet.dao.EmployeeJDBCImple;
import com.capgemini.servlet.dto.EmployeeBean;


public class EmployeeServiceImple implements EmployeeServices {
	
	EmployeeDAO dao = new EmployeeJDBCImple();

	@Override
	public EmployeeBean getEmployeeDetailById(int id) {
		if(id!= 0) {
			return dao.getEmployeeDetailById(id);
		}
		return null;
	}

	@Override
	public boolean deleteEmployeeInfo(int id) {
		if(id!=0) {
			return dao.deleteEmployeeInfo(id);
		}
		return false;
	}

	@Override
	public boolean updateEmployeeInfo(String name) {
		if(name!=null) {
			return dao.updateEmployeeInfo(name);
		}
		return false;
		
	}

	@Override
	public boolean createEmployeeInfo(EmployeeBean bean) {
		if(bean!=null) {
			return dao.createEmployeeInfo(bean);
		}
		return false;
	}

	@Override
	public List<EmployeeBean> getAllEmployeeDetail() {
		return dao.getAllEmployeeDetail();
	}

	@Override
	public EmployeeBean authenticate(int empId, String password) {
		if(empId < 0 || password == null || password.trim().isEmpty()) {
			return null;
		}
		return dao.authenticate(empId,password);
	}

}
